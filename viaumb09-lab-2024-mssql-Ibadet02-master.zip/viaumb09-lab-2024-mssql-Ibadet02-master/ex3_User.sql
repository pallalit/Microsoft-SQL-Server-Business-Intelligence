USE [NEPTUN code]
GO

/****** Object:  Table [dbo].[BXUser]    Script Date: 17-03-2024 17:38:56 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[BXUser](
	[UserID] [int] NULL,
	[Age] [int] NULL,
	[City] [nvarchar](1000) NULL,
	[Country] [nvarchar](1000) NULL
) ON [PRIMARY]
GO


