#### A reminder of how to use the _pull request_:

- Once the pull request is opened, an automated evaluation will be executed. You will see its result in a pull request comment. If you are not satisfied with the result, you can add further commits.
- You are limited to have 5 evaluations. If you do not want the evaluations to run, you should convert this pull request to draft, make further changes, then mark as ready when finished. If you trigger more than 5 evaluations, each one will be penalized.
- Assign the pull request to the instructor when you are finished; this is the final submission.

You can also check the detailed workflow here: <https://bi-labor.github.io/es-mssql/GitHub/>
