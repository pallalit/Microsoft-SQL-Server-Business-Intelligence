USE [NEPTUN code]
GO

/****** Object:  Table [dbo].[BXBooks]    Script Date: 17-03-2024 17:37:01 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[BXBooks](
	[ISBN] [varchar](1000) NULL,
	[Book-Title] [varchar](1000) NULL,
	[Book-Author] [varchar](1000) NULL,
	[Year-Of-Publication] [varchar](1000) NULL,
	[Publisher] [varchar](1000) NULL,
	[Image-URL-S] [varchar](1000) NULL,
	[Image-URL-M] [varchar](1000) NULL,
	[Image-URL-L] [varchar](1000) NULL
) ON [PRIMARY]
GO


