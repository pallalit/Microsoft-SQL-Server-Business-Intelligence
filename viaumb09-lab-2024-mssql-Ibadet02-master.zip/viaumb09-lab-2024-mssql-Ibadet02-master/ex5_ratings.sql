USE [NEPTUN code]
GO

/****** Object:  Table [dbo].[BXBookRatings]    Script Date: 17-03-2024 17:37:43 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[BXBookRatings](
	[ISBN] [varchar](1000) NULL,
	[User-ID] [varchar](50) NULL,
	[Book-Rating] [varchar](50) NULL
) ON [PRIMARY]
GO


